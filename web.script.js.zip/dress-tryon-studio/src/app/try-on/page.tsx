import type { Metadata } from "next";
import TryOnWorkspace from "@/components/TryOnWorkspace";

export const metadata: Metadata = { title: "AI Dress Try-On" };

export default function TryOnPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold tracking-tight">AI Dress Try-On</h1>
        <p className="mt-1.5 max-w-2xl text-black/65">
          Upload a garment photo, choose the model’s gender and the image size, then generate a realistic image of a
          person wearing it.
        </p>
      </div>
      <TryOnWorkspace id="workspace" />
    </div>
  );
}
