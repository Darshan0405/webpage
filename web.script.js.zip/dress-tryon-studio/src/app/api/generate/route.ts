import { NextRequest, NextResponse } from "next/server";
import {
  BACKGROUNDS,
  FRAMINGS,
  GENDERS,
  MAX_OUTPUT_DIM,
  MAX_POSE_CHARS,
  MIN_OUTPUT_DIM,
  SIZE_PRESETS,
  type Background,
  type Framing,
  type Gender,
  type GenerateResponse,
} from "@/lib/constants";
import { generateImage } from "@/lib/gemini";
import {
  UserError,
  finishImage,
  nearestAspectRatio,
  pickImageSize,
  prepareUpload,
} from "@/lib/imageServer";
import { buildPrompt, sanitizePose } from "@/lib/prompt";
import { checkRateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";
export const maxDuration = 300;
export const dynamic = "force-dynamic";

function fail(message: string, status: number, extra?: Record<string, string>) {
  return NextResponse.json({ error: message }, { status, headers: extra });
}

function clientIp(req: NextRequest): string {
  const fwd = req.headers.get("x-forwarded-for");
  return (fwd?.split(",")[0] || req.headers.get("x-real-ip") || "local").trim();
}

function oneOf<T extends string>(value: FormDataEntryValue | null, options: readonly { id: T }[]): T | null {
  if (typeof value !== "string") return null;
  return options.find((o) => o.id === value)?.id ?? null;
}

export async function POST(req: NextRequest) {
  try {
    const max = Number(process.env.MAX_REQUESTS_PER_MINUTE) || 6;
    const rl = checkRateLimit(clientIp(req), max);
    if (!rl.ok) {
      return fail(`Too many requests. Please wait ${rl.retryAfterSec}s and try again.`, 429, {
        "Retry-After": String(rl.retryAfterSec),
      });
    }

    // Reject oversized bodies early (two 10 MB images + form fields).
    const declared = Number(req.headers.get("content-length") || 0);
    if (declared > 25 * 1024 * 1024) return fail("The upload is too large.", 413);

    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return fail("The request could not be read. Please re-upload the image and try again.", 400);
    }

    // ---- Validate fields -------------------------------------------------
    const garment = form.get("garment");
    if (!(garment instanceof File)) return fail("Please upload a dress or clothing image first.", 400);

    const gender = oneOf<Gender>(form.get("gender"), GENDERS);
    if (!gender) return fail("Please select Male or Female.", 400);

    const framing = oneOf<Framing>(form.get("framing"), FRAMINGS) ?? "full";
    const background = oneOf<Background>(form.get("background"), BACKGROUNDS) ?? "white";

    const sizeId = String(form.get("sizeId") ?? "");
    let width: number;
    let height: number;
    if (sizeId === "custom") {
      width = Math.round(Number(form.get("width")));
      height = Math.round(Number(form.get("height")));
      if (
        !Number.isFinite(width) ||
        !Number.isFinite(height) ||
        width < MIN_OUTPUT_DIM ||
        height < MIN_OUTPUT_DIM ||
        width > MAX_OUTPUT_DIM ||
        height > MAX_OUTPUT_DIM
      ) {
        return fail(
          `Custom size must be between ${MIN_OUTPUT_DIM} and ${MAX_OUTPUT_DIM} pixels on each side.`,
          400,
        );
      }
      const ratio = Math.max(width / height, height / width);
      if (ratio > 3) return fail("Custom size is too extreme. Keep the longer side under 3× the shorter side.", 400);
    } else {
      const preset = SIZE_PRESETS.find((s) => s.id === sizeId);
      if (!preset) return fail("Please choose an output size.", 400);
      width = preset.w;
      height = preset.h;
    }

    const pose = sanitizePose(String(form.get("pose") ?? ""), MAX_POSE_CHARS);

    const humanEntry = form.get("humanPhoto");
    const humanFile = humanEntry instanceof File && humanEntry.size > 0 ? humanEntry : null;

    // ---- Validate + normalise images (real byte inspection) ---------------
    const garmentImg = await prepareUpload(garment, "dress image");
    const humanImg = humanFile ? await prepareUpload(humanFile, "model photo") : null;

    // ---- Map requested size to what the provider supports -----------------
    const aspectRatio = nearestAspectRatio(width, height);
    const imageSize = pickImageSize(width, height);

    const prompt = buildPrompt({
      gender,
      framing,
      background,
      pose,
      aspectRatio,
      hasHumanPhoto: !!humanImg,
    });

    // ---- Real AI call -----------------------------------------------------
    const images = [{ base64: garmentImg.base64, mime: garmentImg.mime }];
    if (humanImg) images.push({ base64: humanImg.base64, mime: humanImg.mime });

    const result = await generateImage({
      prompt,
      images,
      aspectRatio,
      imageSize,
      signal: req.signal,
    });

    const finished = await finishImage(result.base64, width, height);

    const body: GenerateResponse = {
      image: finished.dataUrl,
      generated: finished.generated,
      final: finished.final,
      resized: finished.resized,
      upscaled: finished.upscaled,
      aspectRatio,
      imageSize,
      model: result.model,
    };
    return NextResponse.json(body);
  } catch (err) {
    if (err instanceof UserError) return fail(err.message, err.status);
    console.error("[generate] unexpected error:", (err as Error)?.message);
    return fail("Something went wrong on the server. Please try again.", 500);
  }
}

export async function GET() {
  // Lightweight readiness check; never reveals the key itself.
  const configured = !!process.env.GEMINI_API_KEY && !process.env.GEMINI_API_KEY.startsWith("your-");
  return NextResponse.json({ ok: true, aiConfigured: configured });
}
