import type { Metadata } from "next";
import Link from "next/link";
import { site } from "@/config/site";

export const metadata: Metadata = { title: "About & Contact" };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-extrabold tracking-tight">About {site.name}</h1>
      <p className="mt-3 text-black/70">
        {site.name} is a photo editing studio that uses AI to show clothing on realistic models. Instead of arranging a
        photoshoot for every garment, upload one product photo and get a catalogue-style image in a few seconds.
      </p>

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <div className="card p-6">
          <h2 className="font-bold">What the AI does well</h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-black/70">
            <li>Dresses a realistic model in the garment you upload.</li>
            <li>Matches the gender, framing and background you choose.</li>
            <li>Keeps the overall colour, cut and style of the garment.</li>
          </ul>
        </div>
        <div className="card p-6">
          <h2 className="font-bold">Honest limitations</h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-black/70">
            <li>Fine prints, logos, text and embroidery may be simplified or altered.</li>
            <li>Hands and fabric folds can occasionally look imperfect — regenerate if so.</li>
            <li>Each result is an AI approximation, not a photograph of the real garment.</li>
            <li>Results carry an invisible AI watermark from the provider.</li>
          </ul>
        </div>
      </div>

      <section id="contact" className="card mt-8 p-6">
        <h2 className="text-xl font-bold">Contact</h2>
        <p className="mt-1 text-sm text-black/65">Questions, custom work or bulk editing? Get in touch.</p>
        <dl className="mt-4 space-y-2 text-sm">
          <div className="flex gap-3">
            <dt className="w-20 text-black/50">Email</dt>
            <dd>
              <a className="font-semibold text-brand-700 hover:underline" href={`mailto:${site.contactEmail}`}>
                {site.contactEmail}
              </a>
            </dd>
          </div>
          {site.phone && (
            <div className="flex gap-3">
              <dt className="w-20 text-black/50">Phone</dt>
              <dd>{site.phone}</dd>
            </div>
          )}
          {site.address && (
            <div className="flex gap-3">
              <dt className="w-20 text-black/50">Address</dt>
              <dd>{site.address}</dd>
            </div>
          )}
        </dl>
        <Link href="/try-on" className="btn-dark mt-6">
          Try it now
        </Link>
      </section>
    </div>
  );
}
