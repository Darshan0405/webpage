"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { clearHistory, loadHistory, type HistoryItem } from "@/lib/history";

export default function GalleryPage() {
  const [items, setItems] = useState<HistoryItem[] | null>(null);

  useEffect(() => setItems(loadHistory()), []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Gallery</h1>
          <p className="mt-1.5 max-w-2xl text-black/65">
            Thumbnails of your recent try-on results. They are stored only in this browser — never on our server — so
            clearing your browser data removes them. Download full-size files from the result screen.
          </p>
        </div>
        {items && items.length > 0 && (
          <button
            type="button"
            className="btn-ghost text-red-600"
            onClick={() => {
              clearHistory();
              setItems([]);
            }}
          >
            Clear gallery
          </button>
        )}
      </div>

      {items === null ? null : items.length === 0 ? (
        <div className="card grid place-items-center px-6 py-16 text-center">
          <h2 className="text-lg font-bold">No images yet</h2>
          <p className="mt-1 max-w-sm text-sm text-black/60">Generate your first try-on image and it will show up here.</p>
          <Link href="/try-on" className="btn-primary mt-5">
            Start Editing
          </Link>
        </div>
      ) : (
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((it) => (
            <li key={it.id} className="card overflow-hidden">
              <div className="grid aspect-[3/4] place-items-center bg-[#f1f0f6]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={it.thumb} alt={`${it.gender} model, ${it.size}`} className="max-h-full max-w-full object-contain" />
              </div>
              <div className="p-3 text-xs text-black/60">
                <p className="font-semibold capitalize text-ink">
                  {it.gender} · {it.size}
                </p>
                <p>{new Date(it.createdAt).toLocaleString()}</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
