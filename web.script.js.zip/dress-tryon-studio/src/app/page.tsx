import Link from "next/link";
import TryOnWorkspace from "@/components/TryOnWorkspace";
import { site } from "@/config/site";

const steps = [
  { n: "1", title: "Upload the garment", text: "Drop in a photo of a dress, shirt, saree, trousers, gown or any other clothing item." },
  { n: "2", title: "Pick gender & size", text: "Choose a male or female model and the exact output size you need, from 512 px to 4096 px." },
  { n: "3", title: "Generate & download", text: "The AI dresses a realistic model in your garment. Preview, compare and download in PNG or JPEG." },
];

export default function HomePage() {
  return (
    <>
      <section className="relative overflow-hidden bg-ink text-white">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-600/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-20 h-96 w-96 rounded-full bg-brand-800/40 blur-3xl" />
        <div className="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
          <p className="mb-4 inline-block rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-medium text-brand-200">
            {site.name} · AI Photo Studio
          </p>
          <h1 className="max-w-3xl text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">
            See any dress on a real-looking model — in seconds.
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-white/70">
            Upload a clothing photo, choose the model and size, and our AI creates a catalogue-style image of a person
            wearing that garment. No photoshoot, no mannequin.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#workspace" className="btn bg-white text-ink hover:bg-brand-50">
              Start Editing
            </a>
            <Link href="/gallery" className="btn border border-white/20 text-white hover:bg-white/10">
              View Gallery
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <h2 className="text-center text-2xl font-bold tracking-tight">How it works</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {steps.map((s) => (
            <div key={s.n} className="card p-6">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-50 text-sm font-bold text-brand-700">{s.n}</span>
              <h3 className="mt-4 font-bold">{s.title}</h3>
              <p className="mt-1.5 text-sm text-black/65">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-4 sm:px-6">
        <div className="mb-5">
          <h2 className="text-2xl font-bold tracking-tight">AI Dress Try-On</h2>
          <p className="mt-1 text-sm text-black/60">Follow the numbered steps on the left. Your result appears on the right.</p>
        </div>
        <TryOnWorkspace id="workspace" />
      </section>
    </>
  );
}
