import { ALLOWED_EXT_LABEL, ALLOWED_MIME, MAX_UPLOAD_BYTES, MIN_INPUT_DIM } from "./constants";

export interface LoadedImage {
  file: File;
  url: string; // object URL for preview
  width: number;
  height: number;
}

/** Validate type, size and readability in the browser; resolves with a preview. */
export function loadImage(file: File): Promise<LoadedImage> {
  return new Promise((resolve, reject) => {
    if (!(ALLOWED_MIME as readonly string[]).includes(file.type)) {
      reject(new Error(`"${file.name}" is not supported. Please upload a ${ALLOWED_EXT_LABEL} file.`));
      return;
    }
    if (file.size === 0) {
      reject(new Error(`"${file.name}" is empty.`));
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      reject(
        new Error(
          `"${file.name}" is ${(file.size / 1024 / 1024).toFixed(1)} MB. The maximum is ${MAX_UPLOAD_BYTES / 1024 / 1024} MB.`,
        ),
      );
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      if (img.naturalWidth < MIN_INPUT_DIM || img.naturalHeight < MIN_INPUT_DIM) {
        URL.revokeObjectURL(url);
        reject(new Error(`The image is too small (minimum ${MIN_INPUT_DIM}×${MIN_INPUT_DIM} pixels).`));
        return;
      }
      resolve({ file, url, width: img.naturalWidth, height: img.naturalHeight });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(`"${file.name}" could not be read as an image. It may be corrupted.`));
    };
    img.src = url;
  });
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [head, b64] = dataUrl.split(",");
  const mime = /data:(.*?);base64/.exec(head)?.[1] ?? "image/png";
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

/** Re-encode the lossless PNG result as a maximum-quality JPEG. */
export function pngDataUrlToJpegBlob(dataUrl: string): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) return reject(new Error("Canvas is not available in this browser."));
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error("JPEG export failed."))),
        "image/jpeg",
        1.0,
      );
    };
    img.onerror = () => reject(new Error("Could not load the generated image for export."));
    img.src = dataUrl;
  });
}

export function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** Small JPEG thumbnail for the local gallery history. */
export function makeThumbnail(dataUrl: string, maxEdge = 360): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.naturalWidth * scale);
      canvas.height = Math.round(img.naturalHeight * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) return reject(new Error("no canvas"));
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = () => reject(new Error("thumbnail failed"));
    img.src = dataUrl;
  });
}
