// Generation history kept in this browser only (localStorage). Nothing is
// stored on the server, so customer images are never retained there.
// To add accounts + cloud history later, replace these functions with API calls.

export interface HistoryItem {
  id: string;
  createdAt: number;
  thumb: string; // small JPEG data URL
  gender: string;
  size: string; // e.g. "1024 × 1536"
  framing: string;
}

const KEY = "tryon-history-v1";
const MAX_ITEMS = 12;

export function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as HistoryItem[]) : [];
  } catch {
    return [];
  }
}

export function addHistory(item: HistoryItem) {
  try {
    const next = [item, ...loadHistory()].slice(0, MAX_ITEMS);
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage full or unavailable - history is a convenience only */
  }
}

export function clearHistory() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
