import { UserError } from "./imageServer";

/**
 * Google Gemini image generation ("Nano Banana") via the Interactions REST API.
 * Docs: https://ai.google.dev/gemini-api/docs/image-generation
 *
 * The garment photo (and optionally a person photo) are sent as reference
 * images together with the prompt. The API key only ever lives on the server.
 */

export interface GeminiImageInput {
  base64: string;
  mime: string;
}

export interface GeminiRequest {
  prompt: string;
  images: GeminiImageInput[];
  aspectRatio: string;
  imageSize: "1K" | "2K" | "4K";
  signal?: AbortSignal; // aborted when the browser disconnects
}

export interface GeminiResult {
  base64: string;
  model: string;
}

const RETRYABLE = new Set([408, 429, 500, 502, 503, 504]);

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

/** Find the generated image in either response shape. */
function extractImage(json: any): string | null {
  if (json?.output_image?.data) return json.output_image.data;

  const steps = Array.isArray(json?.steps) ? json.steps : [];
  for (let i = steps.length - 1; i >= 0; i--) {
    const step = steps[i];
    if (step?.type !== "model_output") continue;
    const blocks = Array.isArray(step.content) ? step.content : [];
    for (let j = blocks.length - 1; j >= 0; j--) {
      if (blocks[j]?.type === "image" && blocks[j]?.data) return blocks[j].data;
    }
  }

  // Legacy generateContent shape, in case the base URL points to a proxy that uses it.
  const parts = json?.candidates?.[0]?.content?.parts;
  if (Array.isArray(parts)) {
    for (const part of parts) {
      const data = part?.inlineData?.data ?? part?.inline_data?.data;
      if (data) return data;
    }
  }
  return null;
}

function extractText(json: any): string {
  if (typeof json?.output_text === "string") return json.output_text;
  const steps = Array.isArray(json?.steps) ? json.steps : [];
  for (const step of steps) {
    if (step?.type !== "model_output") continue;
    for (const block of step.content ?? []) {
      if (block?.type === "text" && block.text) return String(block.text);
    }
  }
  return "";
}

function mapHttpError(status: number, apiMessage: string): UserError {
  const lower = apiMessage.toLowerCase();
  if (status === 401 || status === 403) {
    return new UserError(
      "The AI service rejected the server's API key. The site owner needs to check GEMINI_API_KEY and that billing is enabled.",
      502,
    );
  }
  if (status === 429) {
    if (lower.includes("quota") || lower.includes("billing") || lower.includes("credit")) {
      return new UserError(
        "The AI service quota or credits have run out. The site owner needs to check billing in Google AI Studio.",
        503,
      );
    }
    return new UserError("The AI service is busy (rate limit reached). Please wait a minute and try again.", 429);
  }
  if (status === 404) {
    return new UserError(
      "The configured AI model was not found. The site owner should update GEMINI_IMAGE_MODEL.",
      502,
    );
  }
  if (status === 400) {
    if (lower.includes("safety") || lower.includes("blocked") || lower.includes("policy")) {
      return new UserError(
        "The AI service declined this image for safety reasons. Try a different garment photo.",
        422,
      );
    }
    return new UserError("The AI service could not process this request. Try a different image or settings.", 422);
  }
  if (status >= 500) {
    return new UserError("The AI service is temporarily unavailable. Please try again shortly.", 503);
  }
  return new UserError("The AI service returned an unexpected error. Please try again.", 502);
}

export async function generateImage(req: GeminiRequest): Promise<GeminiResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.startsWith("your-")) {
    throw new UserError(
      "AI generation is not configured yet. The site owner must set GEMINI_API_KEY on the server.",
      503,
    );
  }
  const model = process.env.GEMINI_IMAGE_MODEL || "gemini-nano-banana-2.1";
  const base = (process.env.GEMINI_API_BASE || "https://generativelanguage.googleapis.com/v1beta").replace(/\/$/, "");
  const timeoutMs = Number(process.env.REQUEST_TIMEOUT_MS) || 120_000;

  const body = JSON.stringify({
    model,
    input: [
      { type: "text", text: req.prompt },
      ...req.images.map((img) => ({ type: "image", mime_type: img.mime, data: img.base64 })),
    ],
    response_format: {
      type: "image",
      mime_type: "image/png",
      aspect_ratio: req.aspectRatio,
      image_size: req.imageSize,
    },
  });

  const maxAttempts = 3;
  let lastError: UserError | null = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (req.signal?.aborted) throw new UserError("Request cancelled.", 499);

    const timeout = AbortSignal.timeout(timeoutMs);
    const signal = req.signal ? AbortSignal.any([req.signal, timeout]) : timeout;

    try {
      const res = await fetch(`${base}/interactions`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body,
        signal,
      });

      const text = await res.text();
      let json: any = null;
      try {
        json = JSON.parse(text);
      } catch {
        /* non-JSON error body */
      }

      if (!res.ok) {
        const apiMessage: string = json?.error?.message || "";
        // Log status + provider message only. Never log request bodies (they contain customer images).
        console.error(`[gemini] HTTP ${res.status} (attempt ${attempt}/${maxAttempts}): ${apiMessage.slice(0, 300)}`);
        lastError = mapHttpError(res.status, apiMessage);
        // Retry transient failures only. Out-of-credits (quota) errors will not fix themselves.
        const outOfCredits = res.status === 429 && lastError.status === 503;
        if (RETRYABLE.has(res.status) && !outOfCredits && attempt < maxAttempts) {
          await sleep(1500 * attempt);
          continue;
        }
        throw lastError;
      }

      const image = extractImage(json);
      if (!image) {
        const note = extractText(json).slice(0, 200);
        console.error(`[gemini] no image in response (attempt ${attempt}/${maxAttempts})`);
        throw new UserError(
          note
            ? `The AI did not return an image: "${note}". Try a clearer garment photo or different settings.`
            : "The AI did not return an image. Try a clearer garment photo or different settings.",
          502,
        );
      }
      return { base64: image, model };
    } catch (err) {
      if (err instanceof UserError) throw err;
      if (req.signal?.aborted) throw new UserError("Request cancelled.", 499);
      const name = (err as Error)?.name;
      const isTimeout = name === "TimeoutError" || name === "AbortError";
      console.error(`[gemini] ${isTimeout ? "timeout" : "network error"} (attempt ${attempt}/${maxAttempts})`);
      lastError = new UserError(
        isTimeout
          ? "The AI service took too long to respond. Please try again."
          : "Could not reach the AI service. Check the server's internet connection and try again.",
        504,
      );
      if (attempt < maxAttempts) {
        await sleep(1500 * attempt);
        continue;
      }
      throw lastError;
    }
  }
  throw lastError ?? new UserError("Image generation failed. Please try again.", 502);
}
