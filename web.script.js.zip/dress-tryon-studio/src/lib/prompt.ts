import type { Background, Framing, Gender } from "./constants";

export interface PromptInput {
  gender: Gender;
  framing: Framing;
  background: Background;
  pose: string; // already sanitized; "" means natural standing pose
  aspectRatio: string;
  hasHumanPhoto: boolean;
}

const FRAMING_TEXT: Record<Framing, string> = {
  full: "full-body shot showing the model from head to toe, with the whole garment visible",
  half: "half-body shot framed from the head to the mid-thigh",
  upper: "upper-body shot framed from the head to the waist, focusing on the neckline, sleeves and chest area of the garment",
};

const BACKGROUND_TEXT: Record<Background, string> = {
  white: "a clean, seamless white studio background",
  grey: "a clean, seamless neutral grey studio background",
  natural: "a softly blurred, natural, tasteful real-world background that does not distract from the garment",
};

export function buildPrompt(p: PromptInput): string {
  const subject = p.gender === "female" ? "female" : "male";
  const pose = p.pose.trim()
    ? `Pose: ${p.pose.trim()}.`
    : "Pose: a relaxed, natural standing pose that shows the garment clearly.";

  const sourceLine = p.hasHumanPhoto
    ? "The first image is the garment reference. The second image is a photo of the person who must wear the garment: keep that person's face, body, skin tone and hairstyle unchanged and dress them in the garment from the first image."
    : "The provided image is the garment reference.";

  return [
    sourceLine,
    `Create a photorealistic fashion catalogue photograph of a realistic ${subject} human model naturally wearing the exact garment shown in the garment reference image.`,
    "Preserve the garment's original color, fabric appearance, pattern, silhouette, cut, length, neckline, sleeves, collar, buttons, embroidery, prints, logos and distinctive details as accurately as possible.",
    "Fit the clothing naturally to the body with realistic fabric draping, folds, seams and shadows. If the garment is a flat-lay or product photo, infer how it would hang and fit when worn, without changing its design.",
    `Composition: ${FRAMING_TEXT[p.framing]}. Background: ${BACKGROUND_TEXT[p.background]}. ${pose}`,
    "Maintain anatomically correct proportions, realistic skin texture, natural hands with the correct number of fingers, professional fashion photography, balanced soft studio lighting, sharp garment details and a clean composition.",
    `Aspect ratio ${p.aspectRatio}.`,
    "Do not redesign the garment, invent additional patterns, replace or add logos or text, or add unrelated accessories. Do not duplicate limbs or distort body parts. Output only the final image.",
  ].join("\n");
}

/** Strip control characters and cap the length of the user-supplied pose text. */
export function sanitizePose(raw: string, max: number): string {
  // eslint-disable-next-line no-control-regex
  return raw.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}
