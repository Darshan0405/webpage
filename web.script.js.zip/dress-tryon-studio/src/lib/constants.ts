// Shared by the browser and the server so both validate identically.

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB
export const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp"] as const;
export const ALLOWED_EXT_LABEL = "JPG, JPEG, PNG or WEBP";
export const MIN_INPUT_DIM = 128;
export const MAX_INPUT_DIM = 8000;

export const MIN_OUTPUT_DIM = 256;
export const MAX_OUTPUT_DIM = 4096;

export type SizeId = "small" | "medium" | "large" | "portrait" | "fullhd" | "custom";

export const SIZE_PRESETS: { id: SizeId; label: string; w: number; h: number }[] = [
  { id: "small", label: "Small", w: 512, h: 512 },
  { id: "medium", label: "Medium", w: 1024, h: 1024 },
  { id: "large", label: "Large", w: 1536, h: 1536 },
  { id: "portrait", label: "Portrait", w: 1024, h: 1536 },
  { id: "fullhd", label: "Full HD", w: 1080, h: 1920 },
];

export const GENDERS = [
  { id: "male", label: "Male" },
  { id: "female", label: "Female" },
] as const;
export type Gender = (typeof GENDERS)[number]["id"];

export const FRAMINGS = [
  { id: "full", label: "Full body" },
  { id: "half", label: "Half body" },
  { id: "upper", label: "Upper body" },
] as const;
export type Framing = (typeof FRAMINGS)[number]["id"];

// "Transparent" is intentionally not offered: the AI provider outputs opaque
// images and cannot produce a real alpha channel.
export const BACKGROUNDS = [
  { id: "white", label: "White studio" },
  { id: "grey", label: "Grey studio" },
  { id: "natural", label: "Natural" },
] as const;
export type Background = (typeof BACKGROUNDS)[number]["id"];

export const MAX_POSE_CHARS = 200;

export interface GenerateResponse {
  image: string; // data URL (PNG)
  generated: { width: number; height: number };
  final: { width: number; height: number };
  resized: boolean;
  upscaled: boolean;
  aspectRatio: string;
  imageSize: string;
  model: string;
}
