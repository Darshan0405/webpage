import sharp from "sharp";
import {
  ALLOWED_MIME,
  MAX_INPUT_DIM,
  MAX_OUTPUT_DIM,
  MAX_UPLOAD_BYTES,
  MIN_INPUT_DIM,
} from "./constants";

export class UserError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

/** Gemini image models' supported aspect ratios. */
const ASPECT_RATIOS: [string, number][] = [
  ["1:1", 1],
  ["3:2", 3 / 2],
  ["2:3", 2 / 3],
  ["3:4", 3 / 4],
  ["4:3", 4 / 3],
  ["4:5", 4 / 5],
  ["5:4", 5 / 4],
  ["9:16", 9 / 16],
  ["16:9", 16 / 9],
  ["21:9", 21 / 9],
];

export function nearestAspectRatio(w: number, h: number): string {
  const target = Math.log(w / h);
  let best = ASPECT_RATIOS[0];
  let bestDiff = Infinity;
  for (const entry of ASPECT_RATIOS) {
    const diff = Math.abs(Math.log(entry[1]) - target);
    if (diff < bestDiff) {
      best = entry;
      bestDiff = diff;
    }
  }
  return best[0];
}

/** Smallest provider resolution tier whose long edge covers the request. */
export function pickImageSize(w: number, h: number): "1K" | "2K" | "4K" {
  const longEdge = Math.max(w, h);
  if (longEdge <= 1024) return "1K";
  if (longEdge <= 2048) return "2K";
  return "4K";
}

export interface PreparedImage {
  base64: string;
  mime: "image/jpeg";
}

/**
 * Validate an uploaded file from its real bytes (not just the claimed MIME
 * type) and re-encode it to a size-capped JPEG for the AI call. Re-encoding
 * also strips metadata (EXIF/GPS) from customer photos.
 */
export async function prepareUpload(file: File, label: string): Promise<PreparedImage> {
  if (file.size === 0) throw new UserError(`The ${label} file is empty.`);
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new UserError(`The ${label} is larger than ${MAX_UPLOAD_BYTES / 1024 / 1024} MB.`, 413);
  }
  if (!(ALLOWED_MIME as readonly string[]).includes(file.type)) {
    throw new UserError(`The ${label} must be a JPG, PNG or WEBP image.`, 415);
  }

  const input = Buffer.from(await file.arrayBuffer());
  let meta: sharp.Metadata;
  try {
    meta = await sharp(input, { limitInputPixels: 80_000_000 }).metadata();
  } catch {
    throw new UserError(`The ${label} could not be read as an image. Please try another file.`, 422);
  }
  const format = meta.format;
  if (!format || !["jpeg", "png", "webp"].includes(format)) {
    throw new UserError(`The ${label} is not a valid JPG, PNG or WEBP image.`, 415);
  }
  const w = meta.width ?? 0;
  const h = meta.height ?? 0;
  if (w < MIN_INPUT_DIM || h < MIN_INPUT_DIM) {
    throw new UserError(`The ${label} is too small (minimum ${MIN_INPUT_DIM}×${MIN_INPUT_DIM}px).`, 422);
  }
  if (w > MAX_INPUT_DIM || h > MAX_INPUT_DIM) {
    throw new UserError(`The ${label} is too large (maximum ${MAX_INPUT_DIM}×${MAX_INPUT_DIM}px).`, 422);
  }

  const jpeg = await sharp(input, { limitInputPixels: 80_000_000 })
    .rotate() // honour EXIF orientation, then metadata is dropped on output
    .resize({ width: 2048, height: 2048, fit: "inside", withoutEnlargement: true })
    .flatten({ background: "#ffffff" }) // transparent PNGs -> white
    .jpeg({ quality: 92, chromaSubsampling: "4:4:4" })
    .toBuffer();

  return { base64: jpeg.toString("base64"), mime: "image/jpeg" };
}

export interface FinishedImage {
  dataUrl: string;
  generated: { width: number; height: number };
  final: { width: number; height: number };
  resized: boolean;
  upscaled: boolean;
}

/**
 * Take the AI output and deliver exactly the requested pixel size.
 * The aspect ratio was chosen to be the nearest supported one, so `cover`
 * only trims a sliver at most. Output is lossless PNG.
 */
export async function finishImage(
  generatedBase64: string,
  targetW: number,
  targetH: number,
): Promise<FinishedImage> {
  const buf = Buffer.from(generatedBase64, "base64");
  let meta: sharp.Metadata;
  try {
    meta = await sharp(buf).metadata();
  } catch {
    throw new UserError("The AI service returned data that is not a valid image. Please try again.", 502);
  }
  const gw = meta.width ?? 0;
  const gh = meta.height ?? 0;
  if (!gw || !gh) throw new UserError("The AI service returned an empty image. Please try again.", 502);

  const tw = Math.min(MAX_OUTPUT_DIM, targetW);
  const th = Math.min(MAX_OUTPUT_DIM, targetH);

  if (gw === tw && gh === th) {
    const png = await sharp(buf).png({ compressionLevel: 6 }).toBuffer();
    return {
      dataUrl: `data:image/png;base64,${png.toString("base64")}`,
      generated: { width: gw, height: gh },
      final: { width: gw, height: gh },
      resized: false,
      upscaled: false,
    };
  }

  const out = await sharp(buf)
    .resize({ width: tw, height: th, fit: "cover", position: "centre", kernel: "lanczos3" })
    .png({ compressionLevel: 6 })
    .toBuffer();
  return {
    dataUrl: `data:image/png;base64,${out.toString("base64")}`,
    generated: { width: gw, height: gh },
    final: { width: tw, height: th },
    resized: true,
    upscaled: tw > gw || th > gh,
  };
}
