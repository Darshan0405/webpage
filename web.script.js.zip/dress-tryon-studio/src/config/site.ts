// Edit this file to rebrand the website.
export const site = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || "Atelier AI Studio",
  // One or two letters shown inside the logo badge. Replace the badge with an
  // <img> in src/components/Logo.tsx if you have a logo file.
  logoMark: "A",
  tagline: "AI virtual dress try-on for photo editing studios",
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "hello@example.com",
  phone: "",
  address: "",
};

export const nav = [
  { href: "/", label: "Home" },
  { href: "/try-on", label: "AI Dress Try-On" },
  { href: "/gallery", label: "Gallery" },
  { href: "/about", label: "About" },
];
