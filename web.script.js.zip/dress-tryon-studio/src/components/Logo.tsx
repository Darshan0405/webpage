import Link from "next/link";
import { site } from "@/config/site";

// To use your own logo image, drop it in /public (e.g. /public/logo.svg) and
// replace the badge <span> below with: <img src="/logo.svg" alt="" className="h-9 w-9" />
export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label={`${site.name} home`}>
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-800 text-base font-bold text-white shadow-sm">
        {site.logoMark}
      </span>
      <span className={`text-base font-bold tracking-tight ${light ? "text-white" : "text-ink"}`}>{site.name}</span>
    </Link>
  );
}
