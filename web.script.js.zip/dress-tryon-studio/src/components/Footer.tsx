import Link from "next/link";
import Logo from "./Logo";
import { nav, site } from "@/config/site";

export default function Footer() {
  return (
    <footer className="mt-16 bg-ink text-white/70">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <Logo light />
          <p className="mt-3 max-w-xs text-sm">{site.tagline}.</p>
        </div>
        <div>
          <p className="mb-3 text-sm font-semibold text-white">Pages</p>
          <ul className="space-y-2 text-sm">
            {nav.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="hover:text-white">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-3 text-sm font-semibold text-white">Contact</p>
          <a href={`mailto:${site.contactEmail}`} className="text-sm hover:text-white">
            {site.contactEmail}
          </a>
          <p className="mt-4 text-xs text-white/50">
            Generated images are AI-made and carry an invisible provider watermark. Always review results before
            showing them to customers.
          </p>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/50">
        © {new Date().getFullYear()} {site.name}. All rights reserved.
      </div>
    </footer>
  );
}
