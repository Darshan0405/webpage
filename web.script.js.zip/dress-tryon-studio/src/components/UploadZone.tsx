"use client";

import { useRef, useState } from "react";
import { loadImage, type LoadedImage } from "@/lib/clientImage";
import { ALLOWED_EXT_LABEL, MAX_UPLOAD_BYTES } from "@/lib/constants";

interface Props {
  value: LoadedImage | null;
  onChange: (img: LoadedImage | null) => void;
  disabled?: boolean;
  title: string;
  hint: string;
  buttonLabel: string;
  compact?: boolean;
  id: string;
}

export default function UploadZone({ value, onChange, disabled, title, hint, buttonLabel, compact, id }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFiles(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setError(null);
    try {
      const loaded = await loadImage(file);
      if (value) URL.revokeObjectURL(value.url);
      onChange(loaded);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  function remove() {
    if (value) URL.revokeObjectURL(value.url);
    onChange(null);
    setError(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  const input = (
    <input
      ref={inputRef}
      id={id}
      type="file"
      accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
      className="sr-only"
      disabled={disabled}
      onChange={(e) => {
        handleFiles(e.target.files);
        e.target.value = ""; // allow re-selecting the same file
      }}
    />
  );

  return (
    <div>
      {value ? (
        <div className="overflow-hidden rounded-2xl border border-black/10 bg-white">
          <div className={`grid place-items-center bg-[#f1f0f6] ${compact ? "h-36" : "h-64"}`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={value.url} alt="Uploaded preview" className="max-h-full max-w-full object-contain" />
          </div>
          <div className="flex items-center justify-between gap-3 p-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold" title={value.file.name}>
                {value.file.name}
              </p>
              <p className="text-xs text-black/55">
                {value.width} × {value.height} px · {(value.file.size / 1024).toFixed(0)} KB
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <button type="button" className="btn-ghost !px-3 !py-2" disabled={disabled} onClick={() => inputRef.current?.click()}>
                Replace
              </button>
              <button type="button" className="btn-ghost !px-3 !py-2 text-red-600" disabled={disabled} onClick={remove}>
                Remove
              </button>
            </div>
          </div>
          {input}
        </div>
      ) : (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            if (!disabled) setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            if (!disabled) handleFiles(e.dataTransfer.files);
          }}
          className={`rounded-2xl border-2 border-dashed text-center transition ${
            compact ? "p-4" : "p-8"
          } ${dragging ? "border-brand-500 bg-brand-50" : "border-black/15 bg-white hover:border-brand-300"}`}
        >
          {!compact && (
            <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 16V4m0 0l-4 4m4-4l4 4M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" />
              </svg>
            </div>
          )}
          <p className="text-sm font-semibold">{title}</p>
          <p className="mx-auto mt-1 max-w-xs text-xs text-black/55">{hint}</p>
          <button
            type="button"
            disabled={disabled}
            onClick={() => inputRef.current?.click()}
            className={`${compact ? "btn-ghost mt-3 !py-2" : "btn-primary mt-4 w-full max-w-xs !py-3.5 text-base"}`}
          >
            {buttonLabel}
          </button>
          <p className="mt-2 text-[11px] text-black/45">
            {ALLOWED_EXT_LABEL} · max {MAX_UPLOAD_BYTES / 1024 / 1024} MB
          </p>
          {input}
        </div>
      )}
      {error && (
        <p role="alert" className="mt-2 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
