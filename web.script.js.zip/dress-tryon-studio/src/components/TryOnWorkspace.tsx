"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import UploadZone from "./UploadZone";
import ResultPanel from "./ResultPanel";
import {
  BACKGROUNDS,
  FRAMINGS,
  GENDERS,
  MAX_OUTPUT_DIM,
  MAX_POSE_CHARS,
  MIN_OUTPUT_DIM,
  SIZE_PRESETS,
  type Background,
  type Framing,
  type Gender,
  type GenerateResponse,
  type SizeId,
} from "@/lib/constants";
import { makeThumbnail, type LoadedImage } from "@/lib/clientImage";
import { addHistory } from "@/lib/history";

type Status = "idle" | "loading" | "success" | "error";

const PROGRESS = [
  { at: 0, text: "Uploading your garment securely…" },
  { at: 4, text: "Sending to the AI model…" },
  { at: 10, text: "Studying the fabric, pattern and cut…" },
  { at: 20, text: "Fitting the garment on the model…" },
  { at: 35, text: "Rendering lighting, folds and details…" },
  { at: 55, text: "Almost there — high-resolution images take a little longer…" },
];

function StepBadge({ n }: { n: number }) {
  return (
    <span className="mr-2 inline-grid h-6 w-6 place-items-center rounded-full bg-ink text-xs font-bold text-white">{n}</span>
  );
}

function Segmented<T extends string>({
  name,
  value,
  options,
  onChange,
  disabled,
}: {
  name: string;
  value: T | "";
  options: readonly { id: T; label: string }[];
  onChange: (v: T) => void;
  disabled?: boolean;
}) {
  return (
    <div role="radiogroup" aria-label={name} className="grid auto-cols-fr grid-flow-col gap-2">
      {options.map((o) => {
        const active = value === o.id;
        return (
          <button
            key={o.id}
            type="button"
            role="radio"
            aria-checked={active}
            disabled={disabled}
            onClick={() => onChange(o.id)}
            className={`rounded-xl border px-3 py-2.5 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 disabled:opacity-50 ${
              active
                ? "border-brand-600 bg-brand-600 text-white shadow-sm"
                : "border-black/10 bg-white text-ink hover:border-brand-300"
            }`}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export default function TryOnWorkspace({ id = "workspace" }: { id?: string }) {
  const [garment, setGarment] = useState<LoadedImage | null>(null);
  const [humanPhoto, setHumanPhoto] = useState<LoadedImage | null>(null);
  const [gender, setGender] = useState<Gender | "">("");
  const [sizeId, setSizeId] = useState<SizeId>("medium");
  const [customW, setCustomW] = useState("1024");
  const [customH, setCustomH] = useState("1536");
  const [framing, setFraming] = useState<Framing>("full");
  const [background, setBackground] = useState<Background>("white");
  const [poseMode, setPoseMode] = useState<"natural" | "custom">("natural");
  const [pose, setPose] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<GenerateResponse | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [formError, setFormError] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const busyRef = useRef(false); // synchronous guard against double clicks
  const resultRef = useRef<HTMLDivElement>(null);
  const busy = status === "loading";

  // Elapsed-seconds ticker for the loading screen.
  useEffect(() => {
    if (!busy) return;
    setElapsed(0);
    const t0 = Date.now();
    const timer = setInterval(() => setElapsed(Math.floor((Date.now() - t0) / 1000)), 500);
    return () => clearInterval(timer);
  }, [busy]);

  // Cancel any in-flight request when leaving the page.
  useEffect(() => () => abortRef.current?.abort(), []);

  const customValid = (() => {
    const w = Number(customW);
    const h = Number(customH);
    return (
      Number.isInteger(w) && Number.isInteger(h) &&
      w >= MIN_OUTPUT_DIM && h >= MIN_OUTPUT_DIM && w <= MAX_OUTPUT_DIM && h <= MAX_OUTPUT_DIM
    );
  })();

  const generate = useCallback(async () => {
    if (busyRef.current) return; // prevent duplicate submissions
    setFormError(null);

    if (!garment) return setFormError("Please upload a dress or clothing image first (step 1).");
    if (!gender) return setFormError("Please select Male or Female (step 2).");
    if (sizeId === "custom" && !customValid) {
      return setFormError(`Custom size must be whole numbers between ${MIN_OUTPUT_DIM} and ${MAX_OUTPUT_DIM}.`);
    }

    busyRef.current = true;
    const controller = new AbortController();
    abortRef.current = controller;
    setStatus("loading");
    setError(null);
    requestAnimationFrame(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }));

    const fd = new FormData();
    fd.append("garment", garment.file);
    if (humanPhoto) fd.append("humanPhoto", humanPhoto.file);
    fd.append("gender", gender);
    fd.append("sizeId", sizeId);
    if (sizeId === "custom") {
      fd.append("width", customW);
      fd.append("height", customH);
    }
    fd.append("framing", framing);
    fd.append("background", background);
    fd.append("pose", poseMode === "custom" ? pose : "");

    try {
      const res = await fetch("/api/generate", { method: "POST", body: fd, signal: controller.signal });
      let data: unknown = null;
      try {
        data = await res.json();
      } catch {
        /* non-JSON response */
      }
      if (!res.ok) {
        const msg = (data as { error?: string } | null)?.error;
        throw new Error(msg || `The server returned an error (${res.status}). Please try again.`);
      }
      const ok = data as GenerateResponse;
      setResult(ok);
      setStatus("success");

      // Save a small thumbnail to this browser's gallery (non-critical).
      makeThumbnail(ok.image)
        .then((thumb) =>
          addHistory({
            id: crypto.randomUUID(),
            createdAt: Date.now(),
            thumb,
            gender,
            size: `${ok.final.width} × ${ok.final.height}`,
            framing,
          }),
        )
        .catch(() => undefined);
    } catch (e) {
      if ((e as Error).name === "AbortError") {
        setStatus(result ? "success" : "idle");
      } else {
        const msg = (e as Error).message;
        setError(msg === "Failed to fetch" ? "Could not reach the server. Check your connection and try again." : msg);
        setStatus("error");
      }
    } finally {
      busyRef.current = false;
      abortRef.current = null;
    }
  }, [garment, humanPhoto, gender, sizeId, customW, customH, customValid, framing, background, poseMode, pose, result]);

  function tryAnother() {
    if (garment) URL.revokeObjectURL(garment.url);
    setGarment(null);
    setResult(null);
    setStatus("idle");
    setError(null);
    setFormError(null);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  const progressText = [...PROGRESS].reverse().find((p) => elapsed >= p.at)?.text ?? PROGRESS[0].text;

  return (
    <section id={id} className="scroll-mt-20">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
        {/* ---------------- Controls ---------------- */}
        <div className="card space-y-6 p-5 sm:p-6">
          <div>
            <h2 className="label !mb-3 text-base">
              <StepBadge n={1} />
              Upload Dress Image
            </h2>
            <UploadZone
              id={`${id}-garment`}
              value={garment}
              onChange={(img) => {
                setGarment(img);
                setFormError(null);
              }}
              disabled={busy}
              title="Drag & drop your garment photo here"
              hint="Dress, shirt, T-shirt, trousers, saree, skirt, gown… A clear, well-lit photo works best."
              buttonLabel="Upload Dress Image"
            />
          </div>

          <div>
            <h2 className="label !mb-3 text-base">
              <StepBadge n={2} />
              Select Human Gender
            </h2>
            <Segmented name="Gender" value={gender} options={GENDERS} onChange={(g) => { setGender(g); setFormError(null); }} disabled={busy} />
          </div>

          <div>
            <h2 className="label !mb-3 text-base">
              <StepBadge n={3} />
              Choose Size
            </h2>
            <select
              aria-label="Choose output size"
              className="field"
              value={sizeId}
              disabled={busy}
              onChange={(e) => setSizeId(e.target.value as SizeId)}
            >
              {SIZE_PRESETS.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label} — {s.w} × {s.h} px
                </option>
              ))}
              <option value="custom">Custom Size…</option>
            </select>
            {sizeId === "custom" && (
              <div className="mt-3 grid grid-cols-2 gap-3">
                <label className="text-xs font-medium text-black/60">
                  Width (px)
                  <input className="field mt-1" inputMode="numeric" value={customW} disabled={busy} onChange={(e) => setCustomW(e.target.value.replace(/\D/g, ""))} />
                </label>
                <label className="text-xs font-medium text-black/60">
                  Height (px)
                  <input className="field mt-1" inputMode="numeric" value={customH} disabled={busy} onChange={(e) => setCustomH(e.target.value.replace(/\D/g, ""))} />
                </label>
                {!customValid && (
                  <p className="col-span-2 text-xs text-red-600">
                    Enter whole numbers from {MIN_OUTPUT_DIM} to {MAX_OUTPUT_DIM}.
                  </p>
                )}
              </div>
            )}
            <p className="mt-2 text-xs text-black/50">
              The AI creates the image at the closest size it supports, then it is resized to exactly what you chose.
              The result screen shows both sizes.
            </p>
          </div>

          <div className="rounded-2xl border border-black/10">
            <button
              type="button"
              className="flex w-full items-center justify-between px-4 py-3 text-left text-sm font-semibold"
              aria-expanded={showAdvanced}
              onClick={() => setShowAdvanced((v) => !v)}
            >
              Optional settings
              <span className="text-black/40">{showAdvanced ? "−" : "+"}</span>
            </button>
            {showAdvanced && (
              <div className="space-y-4 border-t border-black/5 px-4 py-4">
                <div>
                  <p className="label">Framing</p>
                  <Segmented name="Framing" value={framing} options={FRAMINGS} onChange={setFraming} disabled={busy} />
                </div>
                <div>
                  <p className="label">Background</p>
                  <Segmented name="Background" value={background} options={BACKGROUNDS} onChange={setBackground} disabled={busy} />
                </div>
                <div>
                  <p className="label">Pose</p>
                  <Segmented
                    name="Pose"
                    value={poseMode}
                    options={[
                      { id: "natural", label: "Natural standing" },
                      { id: "custom", label: "Custom pose" },
                    ]}
                    onChange={setPoseMode}
                    disabled={busy}
                  />
                  {poseMode === "custom" && (
                    <input
                      className="field mt-2"
                      maxLength={MAX_POSE_CHARS}
                      placeholder="e.g. walking forward, one hand in pocket"
                      value={pose}
                      disabled={busy}
                      onChange={(e) => setPose(e.target.value)}
                    />
                  )}
                </div>
                <div>
                  <p className="label">Your own model photo (optional)</p>
                  <UploadZone
                    id={`${id}-human`}
                    compact
                    value={humanPhoto}
                    onChange={setHumanPhoto}
                    disabled={busy}
                    title="Dress a specific person"
                    hint="Upload a photo of the person; the AI will keep their face and body and put the garment on them. Only use photos you have permission to use."
                    buttonLabel="Upload Human Model Photo"
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <button type="button" className="btn-primary w-full !py-4 text-base" disabled={busy} onClick={generate}>
              {busy ? "Generating…" : status === "success" ? "OK — Generate Again" : "OK — Generate AI Image"}
            </button>
            {formError && (
              <p role="alert" className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">
                {formError}
              </p>
            )}
          </div>
        </div>

        {/* ---------------- Result area ---------------- */}
        <div ref={resultRef} className="card min-h-[420px] scroll-mt-24 p-5 sm:p-6" aria-live="polite">
          {status === "idle" && !result && (
            <div className="grid h-full min-h-[360px] place-items-center text-center">
              <div className="max-w-sm">
                <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-3xl bg-brand-50 text-brand-600">
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 3l4 3 4-3 5 4-3 4v10H6V11L3 7z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold">Your result will appear here</h3>
                <ol className="mt-3 space-y-1.5 text-left text-sm text-black/65">
                  <li>1. Upload a photo of the garment.</li>
                  <li>2. Pick Male or Female.</li>
                  <li>3. Choose the output size.</li>
                  <li>4. Press <b>OK — Generate AI Image</b> (takes about 10–60 seconds).</li>
                </ol>
              </div>
            </div>
          )}

          {status === "loading" && (
            <div className="grid min-h-[360px] place-items-center text-center" role="status">
              <div>
                <div className="mx-auto h-14 w-14 animate-spin rounded-full border-4 border-brand-100 border-t-brand-600" />
                <h3 className="mt-5 text-lg font-bold">Creating your image</h3>
                <p className="mt-1 text-sm text-black/65">{progressText}</p>
                <p className="mt-3 text-xs text-black/45">{elapsed}s elapsed · please keep this page open</p>
                <button
                  type="button"
                  className="btn-ghost mt-5 !py-2"
                  onClick={() => abortRef.current?.abort()}
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {status === "error" && (
            <div className="grid min-h-[360px] place-items-center text-center" role="alert">
              <div className="max-w-md">
                <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-3xl bg-red-50 text-red-600">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M12 8v5m0 3.5h.01M10.3 3.9L2.4 18a2 2 0 001.7 3h15.8a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold">Generation didn’t work</h3>
                <p className="mt-2 text-sm text-black/70">{error}</p>
                <button type="button" className="btn-primary mt-5" onClick={generate}>
                  Try again
                </button>
              </div>
            </div>
          )}

          {status === "success" && result && garment && (
            <ResultPanel
              result={result}
              originalUrl={garment.url}
              busy={busy}
              onRegenerate={generate}
              onTryAnother={tryAnother}
            />
          )}
          {status === "success" && result && !garment && (
            <ResultPanel result={result} originalUrl={result.image} busy={busy} onRegenerate={generate} onTryAnother={tryAnother} />
          )}
        </div>
      </div>
    </section>
  );
}
