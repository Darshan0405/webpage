# Atelier AI Studio — AI Virtual Dress Try-On

A Next.js website for a photo editing shop. A customer uploads a photo of a garment, picks **Male / Female** and an **output size**, presses **OK — Generate AI Image**, and the server asks a real AI image model to produce a photorealistic person wearing that garment. The result can be compared with the original, viewed full screen and downloaded as PNG or JPEG.

## 1. AI model used, and why

**Google Gemini image generation ("Nano Banana"), default model `gemini-nano-banana-2.1`**, called through the Gemini Interactions REST API (`POST /v1beta/interactions`). Docs: <https://ai.google.dev/gemini-api/docs/image-generation>.

| Question | Answer |
|---|---|
| Does it accept a garment image **without** a person photo? | Yes. It is an image-editing / reference-conditioned model: the garment photo is sent as a reference image together with the prompt, and the model creates the person. This is documented for the API (text + image input → image output). |
| Is it a dedicated "virtual try-on" model? | No. Dedicated try-on models (e.g. FASHN-style APIs) need a **garment image + a person image** and cannot invent the person. This project uses a general image model so garment-only input works. If you want the person-photo workflow, the **optional "Your own model photo"** field sends it as a second reference image. |
| Garment accuracy | Good for colour, cut and silhouette. **Not guaranteed** for small prints, logos, text, lace or embroidery — these can be simplified or altered. The UI says so. Always review results. |
| Output sizes | Provider supports fixed aspect ratios (1:1, 2:3, 3:2, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9) and 1K / 2K / 4K tiers. The server picks the nearest ratio and tier, then resizes (Lanczos) to your exact pixels. The result screen shows **AI-generated size vs final size** and warns when it had to upscale. Sizes above the generated size are enlarged, which adds no real detail. |
| Transparent background | **Not offered** — the model outputs opaque images. Use a background-removal tool afterwards. |
| Watermark | All images carry Google's invisible SynthID watermark. |
| Cost | Paid API; billing must be enabled. Roughly **$0.04–$0.15 per image** depending on model and resolution (check <https://ai.google.dev/gemini-api/docs/pricing> — prices and model names change). Failed requests may still be billed for the input. |
| Content policy | Google may refuse some images for safety reasons; the site shows a friendly message. Only upload images you have the rights to, and only use a person's photo with their permission. |

Model names change frequently. The model ID is an environment variable (`GEMINI_IMAGE_MODEL`), so you can switch (e.g. `gemini-3-pro-image` for higher fidelity, at higher cost) without touching code.

## 2. Stack

- **Next.js 15 (App Router) + React 19 + TypeScript**, **Tailwind CSS 3** — one deployable app, frontend and API together.
- **Sharp** — server-side image inspection, EXIF-orientation fix, metadata stripping, resizing, PNG output.
- **No database, no file storage.** Uploads are processed in memory and never written to disk, so there is nothing to clean up and no private image can be exposed by URL. The generated image goes straight back to the browser as base64. The gallery keeps small thumbnails in the visitor's own browser (`localStorage`).

## 3. Setup

Requires Node.js 20+.

```bash
npm install
cp .env.example .env.local      # then edit .env.local
npm run dev                     # http://localhost:3000
```

### Get and set the API key
1. Open <https://aistudio.google.com/apikey> and sign in with a Google account.
2. Create an API key, and **enable billing** for the project (image models are not on the free tier).
3. Put it in `.env.local`: `GEMINI_API_KEY=...`
4. Restart `npm run dev`.

Until a key is set, the Generate button still runs the real workflow and returns a clear "AI generation is not configured" message. `GET /api/generate` returns `{ aiConfigured: true|false }` as a quick check (never the key).

### Rebrand
Edit `src/config/site.ts` (name, logo letter, contact details, navigation). To use a logo image, edit `src/components/Logo.tsx`.

## 4. Project structure

```
src/
  app/
    page.tsx              Home + embedded workspace
    try-on/page.tsx       Full workspace page
    gallery/page.tsx      Recent results (this browser only)
    about/page.tsx        About + Contact
    api/generate/route.ts Validation → AI call → resize → response
  components/             Header, Footer, Logo, UploadZone, TryOnWorkspace, ResultPanel
  lib/
    constants.ts          Sizes, limits, option lists (shared client/server)
    prompt.ts             Dynamic prompt builder
    gemini.ts             Gemini REST client (timeouts, retries, error mapping)
    imageServer.ts        Byte-level validation, aspect/size mapping, final resize
    rateLimit.ts          Per-IP limiter
    clientImage.ts        Browser validation, previews, PNG/JPEG export
    history.ts            localStorage history
  config/site.ts          Branding
```

## 5. Security and reliability built in

- API key lives only in server env vars; never sent to the browser. Requests to Gemini use a header, never a URL.
- Server validates everything again: MIME type **and** real file bytes (Sharp), size ≤ 10 MB, dimensions, enums, custom size range, pose text (control characters stripped, 200 chars).
- Re-encoding strips EXIF/GPS from customer photos before they leave your server.
- Per-IP rate limit (`MAX_REQUESTS_PER_MINUTE`, default 6). The limiter is in-memory: use Redis/Upstash if you run several instances or serverless.
- 120 s timeout per attempt, up to 3 attempts on transient errors (429/5xx/network), no retry when credits are exhausted.
- Friendly messages for: bad key, no credits, rate limit, safety refusal, no image returned, timeout, offline.
- Logs contain status codes only — never images or keys.
- Duplicate submissions are blocked; the user can cancel a running generation.
- If you add customer accounts later, scope every record by user id and keep images in private storage with short-lived signed URLs.

## 6. Deployment

The API route can run for up to ~2 minutes, so the host must allow long requests.

- **Your own server / VPS (simplest):** `npm run build && npm start` behind Nginx/Caddy with HTTPS. Set env vars in the service environment. Set a generous proxy timeout (≥ 180 s) and `client_max_body_size 25m`.
- **Docker / Cloud Run / Fly.io / Railway / Render:** any Node host works; set the same env vars.
- **Vercel:** works; set env vars in Project Settings. `maxDuration` is set to 300 s in the route, but your plan's function limit applies (Hobby plans may cut requests off earlier — use Pro or another host). Request bodies are limited to ~4.5 MB on Vercel functions, so large phone photos may be rejected there; a VPS or container host avoids this.
- Always serve over HTTPS and keep `.env.local` out of git (already in `.gitignore`).

## 7. Adding the optional features later

| Feature | Where to hook in |
|---|---|
| Login + saved history | Replace `lib/history.ts` with API calls; add auth (e.g. Auth.js) and private storage |
| Credits / payments | Check and decrement credits at the top of `api/generate/route.ts` |
| Multiple poses / body types | Loop `generateImage` with different `pose` values; extend `prompt.ts` |
| Watermark / logo | Add a Sharp `composite` step in `finishImage` |
| Background removal / upscaling | Add a post-processing step after `generateImage` |
| Admin dashboard | Log counts (not images) per request, then chart them |

## 8. Known limits

- Garment detail fidelity is best-effort (see section 1).
- Generation takes roughly 10–60 s; 4K takes longer.
- Gallery thumbnails live in the visitor's browser only.
